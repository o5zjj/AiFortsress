import subprocess
import os

def run_bandit(path="flagged_projects"):
    print(f"🔍 Running Bandit scan in: {path}")
    output_dir = "analysis_reports/bandit"
    os.makedirs(output_dir, exist_ok=True)

    for root, dirs, files in os.walk(path):
        for file in files:
            if file.endswith(".py"):
                file_path = os.path.join(root, file)
                out_file = os.path.join(output_dir, file.replace("/", "_") + "_bandit.json")
                subprocess.run([
                    "bandit", "-r", file_path, "-f", "json", "-o", out_file
                ])

if __name__ == "__main__":
    run_bandit()
