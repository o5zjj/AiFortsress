import subprocess
import os

def run_trivy(path="flagged_projects"):
    print("🔍 Running Trivy scan...")
    output_dir = "analysis_reports/trivy"
    os.makedirs(output_dir, exist_ok=True)

    for root, dirs, files in os.walk(path):
        if "requirements.txt" in files:
            subprocess.run([
                "trivy", "fs", root,
                "--format", "json",
                "--output", os.path.join(output_dir, f"{root.replace('/', '_')}_trivy.json")
            ])

if __name__ == "__main__":
    run_trivy()
