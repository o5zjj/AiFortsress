
import os
import subprocess
import json
from pathlib import Path

ROOT_DIR = "smart_collected_projects/smart_collected_projects"
DB_DIR = "codeql_databases"
RESULTS_DIR = "analysis_reports/codeql"
FAILED_LOG = "flagged_projects/codeql_failed.json"

LANGUAGE_MAP = {
    "java": "codeql/java-queries",
    "python": "codeql/python-queries",
    "javascript": "codeql/javascript-queries",
    "cpp": "codeql/cpp-queries",
    "csharp": "codeql/csharp-queries",
    "go": "codeql/go-queries",
    "ruby": "codeql/ruby-queries",
    "swift": "codeql/swift-queries"
}

ext_map = {
    ".py": "python", ".java": "java", ".js": "javascript",
    ".cpp": "cpp", ".c": "cpp", ".cs": "csharp",
    ".go": "go", ".rb": "ruby", ".swift": "swift"
}

os.makedirs(DB_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs("flagged_projects", exist_ok=True)

def detect_language(project_path):
    counts = {lang: 0 for lang in LANGUAGE_MAP}
    for root, _, files in os.walk(project_path):
        for file in files:
            ext = Path(file).suffix.lower()
            lang = ext_map.get(ext)
            if lang:
                counts[lang] += 1
    sorted_langs = sorted(counts.items(), key=lambda x: x[1], reverse=True)
    return sorted_langs[0][0] if sorted_langs[0][1] > 0 else None

def finalize_database(db_path):
    try:
        subprocess.run(["codeql", "database", "finalize", db_path], check=True)
    except:
        pass

def install_query_packs():
    print("📦 تثبيت حزم الاستعلام لجميع اللغات المدعومة...")
    for lang, pack in LANGUAGE_MAP.items():
        try:
            subprocess.run(["codeql", "pack", "install", pack], check=True)
        except subprocess.CalledProcessError:
            print(f"❌ فشل تثبيت الحزمة: {pack}")

def run_codeql_scan(project_path, language):
    project_name = Path(project_path).name
    db_path = os.path.join(DB_DIR, f"{project_name}_{language}_db")
    result_file = os.path.join(RESULTS_DIR, f"{project_name}_{language}_results.sarif")
    query_pack = LANGUAGE_MAP[language]

    try:
        subprocess.run([
            "codeql", "database", "create", db_path,
            "--language", language,
            "--source-root", project_path,
            "--overwrite"
        ], check=True)
    except subprocess.CalledProcessError:
        print(f"⚠️ {project_name}: فشل إنشاء قاعدة البيانات")
        return False

    finalize_database(db_path)

    try:
        subprocess.run([
            "codeql", "database", "analyze", db_path, query_pack,
            "--format=sarifv2.1.0",
            "--output", result_file
        ], check=True)

        if os.path.exists(result_file):
            print(f"✅ {project_name} ({language}) → فحص ناجح، النتيجة: {result_file}")
            return True
        else:
            print(f"⚠️ {project_name} ({language}) → لم يتم العثور على ملف النتيجة!")
            return False
    except subprocess.CalledProcessError:
        print(f"❌ {project_name} ({language}) → فشل التحليل")
        return False

def main():
    install_query_packs()
    failed_projects = []

    for project in os.listdir(ROOT_DIR):
        project_path = os.path.join(ROOT_DIR, project)
        if not os.path.isdir(project_path):
            continue

        language = detect_language(project_path)
        if not language:
            print(f"⚠️ {project} → لا يوجد كود بلغة مدعومة")
            failed_projects.append({"project": project, "reason": "no supported language"})
            continue

        if not run_codeql_scan(project_path, language):
            failed_projects.append({"project": project, "language": language})

    if failed_projects:
        with open(FAILED_LOG, "w", encoding="utf-8") as f:
            json.dump(failed_projects, f, indent=2, ensure_ascii=False)
        print(f"🚫 المشاريع الفاشلة محفوظة في: {FAILED_LOG}")

if __name__ == "__main__":
    print("🚀 بدء فحص CodeQL لجميع المشاريع...")
    main()
