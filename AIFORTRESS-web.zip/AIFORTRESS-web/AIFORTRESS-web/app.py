
import os, json, uuid, shutil, tempfile, subprocess, sys
from pathlib import Path
from flask import Flask, request, send_from_directory, jsonify, send_file
from flask_cors import CORS

app = Flask(__name__, static_folder='.', static_url_path='')
# ==== Ollama helpers (Qwen) ====
def _ollama_host():
    return os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")

def _ollama_model():
    return os.environ.get("OLLAMA_MODEL", "qwen2.5:7b")

def call_qwen(prompt: str, system: str = None) -> str:
    """Try /api/chat; if 404, fall back to /api/generate (older Ollama)."""
    try:
        import requests
        host = _ollama_host()
        model = _ollama_model()

        # 1) حاول /api/chat
        try:
            url = f"{host}/api/chat"
            payload = {
                "model": model,
                "messages": ([{"role":"system","content": system}] if system else [])
                            + [{"role":"user","content": prompt}],
                "stream": False
            }
            r = requests.post(url, json=payload, timeout=60)
            if r.status_code == 404:
                raise FileNotFoundError("chat endpoint not found")
            r.raise_for_status()
            data = r.json()
            msg = (data.get("message") or {}).get("content") or data.get("response") or ""
            if msg:
                return msg
        except Exception:
            # 2) رجوع إلى /api/generate
            url = f"{host}/api/generate"
            full_prompt = f"System: {system}\n\nUser: {prompt}" if system else prompt
            payload = {"model": model, "prompt": full_prompt, "stream": False}
            r = requests.post(url, json=payload, timeout=60)
            r.raise_for_status()
            data = r.json()
            return data.get("response") or "[empty response]"

        return "[empty response]"
    except Exception as e:
        return f"[Qwen/Ollama error: {e}]"

def _ollama_host():
    return os.environ.get('OLLAMA_HOST', 'http://127.0.0.1:11434').rstrip('/')

def _ollama_model():
    return os.environ.get('OLLAMA_MODEL', 'qwen2.5:7b')

CORS(app, resources={r"/api/*": {"origins": "*"}})

REPORTS_DIR = Path("reports")
UPLOADS_DIR = Path("uploads")
REPORTS_DIR.mkdir(exist_ok=True)
UPLOADS_DIR.mkdir(exist_ok=True)

def tool_available(bin_name):
    from shutil import which
    return which(bin_name) is not None

def summarize_bandit(json_obj):
    findings = []
    counts = {"HIGH":0, "MEDIUM":0, "LOW":0}
    try:
        for res in json_obj.get("results", []):
            sev = (res.get("issue_severity") or "").upper()
            if sev in counts: counts[sev] += 1
            findings.append({
                "title": res.get("test_name") or "Bandit Issue",
                "description": res.get("issue_text"),
                "severity": sev,
                "location": f"{res.get('filename')}:{res.get('line_number')}"
            })
    except Exception:
        pass
    return counts, findings

def summarize_trivy(json_obj):
    counts = {"HIGH":0, "MEDIUM":0, "LOW":0}
    findings = []
    for res in json_obj if isinstance(json_obj, list) else []:
        for result in res.get("Results", []):
            for vuln in result.get("Vulnerabilities", []) or []:
                sev = (vuln.get("Severity") or "").upper()
                if sev in counts: counts[sev] += 1
                title = vuln.get("Title") or vuln.get("VulnerabilityID")
                findings.append({
                    "title": title,
                    "description": vuln.get("Description") or "",
                    "severity": sev,
                    "location": f"{result.get('Target')}::{vuln.get('PkgName')} {vuln.get('InstalledVersion')}"
                })
    return counts, findings

@app.post("/api/analyze")
def analyze():
    tool = request.form.get("tool", "").lower()
    f = request.files.get("file")
    if not f or tool not in ("bandit","trivy","codeql"):
        return jsonify({"error":"Missing file or tool"}), 400

    job_id = str(uuid.uuid4())[:8]
    work_dir = UPLOADS_DIR / job_id
    work_dir.mkdir(parents=True, exist_ok=True)
    up_path = work_dir / f.filename
    f.save(up_path)

    job = {
        "id": job_id,
        "tool": tool,
        "file": {"name": f.filename, "size": up_path.stat().st_size},
        "summaryCounts": {"HIGH":0,"MEDIUM":0,"LOW":0},
        "findings": []
    }

    # Run per tool
    try:
        if tool == "bandit":
            # If archive, extract; else scan single file/dir
            scan_path = work_dir
            if up_path.suffix.lower() in (".zip",".tar",".gz",".tgz",".tar.gz"):
                scan_path = work_dir / "unpacked"
                scan_path.mkdir(exist_ok=True)
                try:
                    shutil.unpack_archive(str(up_path), str(scan_path))
                except Exception:
                    scan_path = work_dir  # fallback
            # Prefer calling bandit if available
            if tool_available("bandit"):
                out_json = work_dir / "bandit_report.json"
                cmd = ["bandit","-r",str(scan_path),"-f","json","-o",str(out_json)]
                subprocess.run(cmd, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                if out_json.exists():
                    data = json.loads(out_json.read_text(encoding="utf-8") or "{}")
                    counts, findings = summarize_bandit(data)
                    job["summaryCounts"] = counts
                    job["findings"] = findings
                else:
                    job["findings"] = [{"title":"Bandit did not produce output","severity":"LOW","description":"Check that Bandit is installed and the file is a Python project."}]
            else:
                # Fallback lightweight heuristic scan
                txt = up_path.read_text(errors="ignore")
                heur = [
                    ("Use of eval()", "HIGH", "Found 'eval(' which can execute arbitrary code."),
                    ("Use of exec()", "HIGH", "Found 'exec(' which can execute arbitrary code."),
                    ("Hardcoded password", "MEDIUM", "Found string that looks like a password assignment."),
                ]
                findings = []
                for title, sev, desc in heur:
                    if ("eval(" in txt and "eval" in title) or ("exec(" in txt and "exec" in title) or re.search(r"password\s*=", txt, re.I):
                        findings.append({"title":title,"description":desc,"severity":sev,"location": f"{f.filename}"})
                counts = {"HIGH": sum(1 for x in findings if x["severity"]=="HIGH"),
                          "MEDIUM": sum(1 for x in findings if x["severity"]=="MEDIUM"),
                          "LOW": sum(1 for x in findings if x["severity"]=="LOW")}
                job["summaryCounts"] = counts
                job["findings"] = findings

        elif tool == "trivy":
            # Trivy filesystem scan on a folder (extract archives)
            scan_path = work_dir
            if up_path.suffix.lower() in (".zip",".tar",".gz",".tgz",".tar.gz"):
                scan_path = work_dir / "unpacked"
                scan_path.mkdir(exist_ok=True)
                try:
                    shutil.unpack_archive(str(up_path), str(scan_path))
                except Exception:
                    scan_path = work_dir
            if tool_available("trivy"):
                out_json = work_dir / "trivy_report.json"
                cmd = ["trivy","fs",str(scan_path),"--format","json","--output",str(out_json)]
                subprocess.run(cmd, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                if out_json.exists():
                    data = json.loads(out_json.read_text(encoding="utf-8") or "[]")
                    counts, findings = summarize_trivy(data if isinstance(data, list) else [data])
                    job["summaryCounts"] = counts
                    job["findings"] = findings
                else:
                    job["findings"] = [{"title":"Trivy did not produce output","severity":"LOW","description":"Ensure Trivy is installed and target contains lockfiles or manifests."}]
            else:
                job["findings"] = [{"title":"Trivy not installed","severity":"LOW","description":"Install Trivy to run a real scan: https://aquasecurity.github.io/trivy/"}]

        elif tool == "codeql":
            # For simplicity, acknowledge and return a stub if CodeQL not present
            if not tool_available("codeql"):
                job["findings"] = [{"title":"CodeQL not installed","severity":"LOW","description":"Install CodeQL CLI and set PATH, then integrate with your databases as in codeql_scan.py."}]
            else:
                # Minimal attempt: just state that CodeQL is available and project uploaded.
                job["findings"] = [{"title":"CodeQL environment detected","severity":"LOW","description":"Set up a CodeQL database for the uploaded project, then run queries as in codeql_scan.py."}]
        else:
            pass
    except Exception as e:
        job["findings"] = [{"title":"Analyzer error","severity":"LOW","description":str(e)}]

    # Save job json
    out_json = REPORTS_DIR / f"{job_id}.json"
    out_json.write_text(json.dumps(job, ensure_ascii=False, indent=2), encoding="utf-8")
    job['job_id'] = job.get('id'); return jsonify(job)

# Health
@app.route("/api/health", methods=["GET"])
def health():
    import requests
    host = _ollama_host().rstrip("/")
    info = {"status":"ok","ollama":"down","host": host}
    try:
        vr = requests.get(host + "/api/version", timeout=5)
        if vr.ok:
            info["ollama"] = "up"
            try:
                info["version"] = vr.json().get("version")
            except Exception:
                pass
        try:
            tags = requests.get(host + "/api/tags", timeout=5)
            if tags.ok:
                info["models"] = [m.get("name") for m in tags.json().get("models", [])]
        except Exception:
            pass
    except Exception as e:
        info["error"] = str(e)
    return jsonify(info)

# Qwen suggestions من تقرير آخر تحليل
@app.route("/api/qwen_suggest", methods=["POST","OPTIONS"])
def qwen_suggest():
    try:
        data = request.get_json(force=True) or {}
        job_id = data.get("job_id")
        if not job_id:
            return jsonify({"error":"job_id required"}), 400

        report_path = REPORTS_DIR / f"{job_id}.json"
        if not report_path.exists():
            return jsonify({"error":"report not found","job_id": job_id}), 404

        report = json.loads(report_path.read_text(encoding="utf-8"))
        bandit_sum = report.get("bandit_summary","")
        trivy_sum  = report.get("trivy_summary","")
        issues = []
        for sec in report.get("findings", []):
            if isinstance(sec, dict):
                name = sec.get("id") or sec.get("rule_id") or sec.get("target") or "issue"
                sev  = sec.get("severity","")
                msg  = sec.get("message","") or sec.get("title","")
                issues.append(f"- [{sev}] {name}: {msg}")
        top_issues = "\n".join(issues[:20])

        system = ("You are a senior DevSecOps assistant. Provide concrete fixes and minimal patches. "
                  "Prefer code/config snippets. Keep it practical.")
        prompt = (
            "Project scan report:\n"
            f"BANDIT SUMMARY:\n{bandit_sum[:2000]}\n\n"
            f"TRIVY SUMMARY:\n{trivy_sum[:2000]}\n\n"
            f"Top issues:\n{top_issues}\n\n"
            "Task: Propose prioritized, step-by-step fixes grouped by tool (Bandit/Trivy)."
        )
        answer = call_qwen(prompt, system=system)
        return jsonify({"suggestions": str(answer)[:20000]})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# شات مباشر مع الذكاء المحلي
@app.route("/api/ai/chat", methods=["POST","OPTIONS"])
def ai_chat():
    try:
        data = request.get_json(force=True) or {}
        messages = data.get("messages") or []
        system   = data.get("system") or "You are a helpful security assistant."
        context  = data.get("context") or ""
        convo = []
        for m in messages[-20:]:
            role = m.get("role","user")
            content = m.get("content","")
            if not content: 
                continue
            if role == "system":
                system = content
            else:
                convo.append(f"{role}: {content}")
        if context:
            convo.insert(0, f"Context:\n{context}\n---")
        prompt = "\n".join(convo) if convo else "Hello"
        reply = call_qwen(prompt, system=system)
        return jsonify({"reply": str(reply)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent  # مكان index.html و results.html وملفات الواجهة

# الصفحة الرئيسية
@app.route("/", methods=["GET"])
def home():
    return send_from_directory(BASE_DIR, "index.html")

# صفحة النتائج
@app.route("/results.html", methods=["GET"])
def results_page():
    return send_from_directory(BASE_DIR, "results.html")

# أي ملف ثابت (css/js/png الخ)
@app.route("/<path:filename>", methods=["GET"])
def static_files(filename):
    # نتجنّب تضارب مع API
    if filename.startswith("api/"):
        return jsonify({"error": "not found", "path": "/" + filename}), 404
    return send_from_directory(BASE_DIR, filename)

if __name__ == "__main__":
    # شغّل Flask على المنفذ 8000 مع وضع التصحيح
    app.run(host="0.0.0.0", port=8000, debug=True)

