
# AIFORTRESS Analyzer (wired)

This package wires your existing UI to real tool runs.

## How to run (Windows/Mac/Linux)
1. Install Python 3.10+
2. In a terminal, go to this folder (`AIFORTRESS/AIFORTRESS`).
3. Install deps: 
   ```bash
   pip install -r requirements.txt
   ```
4. Start the server:
   ```bash
   python app.py
   ```
5. Open: http://localhost:8000

## Using the tools
- **Bandit**: Upload a `.py` file or a project archive. If Bandit is installed in your PATH, it will run and populate the report. If not, a lightweight fallback heuristic runs.
- **Trivy**: Upload a project folder as `.zip` or a directory with manifests; if Trivy is installed it will scan with `trivy fs`.
- **CodeQL**: If CodeQL CLI is in PATH, the backend acknowledges the environment. To do full scans, follow your `codeql_scan.py` flow to create databases then query.

The **Results** page reads the last job from `localStorage` and renders counts + issues. "Download PDF" triggers browser print to PDF. Raw JSON is saved under `reports/<job_id>.json`.
