from fastapi import FastAPI, UploadFile, File, Form
import subprocess
import requests
import json

app = FastAPI()

@app.post("/diagnose_car_issue")
async def diagnose_car(
    description: str = Form(...),
    obd_code: str = Form(None),
    audio: UploadFile = File(None),
    image: UploadFile = File(None)
):
    # 1. معالجة المدخلات
    inputs = {
        "description": description,
        "obd_code": obd_code,
        "audio_transcript": await transcribe_audio(audio) if audio else None,
        "image_analysis": await analyze_image(image) if image else None
    }

    # 2. إرسال إلى نموذج DeepSeek المحلي
    diagnosis = await query_deepseek_model(inputs)
    
    return {"diagnosis": diagnosis}

async def query_deepseek_model(inputs: dict):
    # هنا تُرسل البيانات إلى نموذجك المحلي (عدّل بناءً على واجهته)
    prompt = f"""
    وصفح العطل: {inputs['description']}
    رمز OBD-II: {inputs['obd_code']}
    نص الصوت: {inputs['audio_transcript']}
    تحليل الصورة: {inputs['image_analysis']}
    """
    # استدعاء النموذج المحلي (مثال باستخدام HTTP)
    response = requests.post("http://localhost:5000/v1/chat", json={"prompt": prompt})
    return response.json()["response"]

async def transcribe_audio(audio_file: UploadFile):
    # استخدم مكتبة مثل Whisper لتحويل الصوت لنص
    import whisper
    model = whisper.load_model("base")
    result = model.transcribe(await audio_file.read())
    return result["text"]

async def analyze_image(image_file: UploadFile):
    # استخدم OpenCV أو YOLO لتحليل الصور
    import cv2
    import numpy as np
    image_data = await image_file.read()
    nparr = np.frombuffer(image_data, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    # مثال: كشف وجود تسريب زيت (تخصيص حسب حاجتك)
    is_oil_leak = detect_oil_leak(img)
    return f"تسريب زيت: {'نعم' if is_oil_leak else 'لا'}"

def detect_oil_leak(image):
    # خوارزمية بسيطة لتحليل الصورة (تطوّرها حسب حاجتك)
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    lower_black = np.array([0, 0, 0])
    upper_black = np.array([180, 255, 50])
    mask = cv2.inRange(hsv, lower_black, upper_black)
    return np.sum(mask) > 10000  # حدد العتبة المناسبة