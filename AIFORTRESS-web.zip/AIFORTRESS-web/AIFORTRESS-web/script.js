
let currentTool = 'bandit';
function switchTool(tool) {
  currentTool = tool;
  document.querySelectorAll("nav button").forEach(btn => btn.classList.remove("active"));
  let label = document.getElementById("toolLabel");
  let input = document.getElementById("fileInput");
  if (tool === "bandit") {
    document.getElementById("banditBtn").classList.add("active");
    label.innerText = "Upload Python file for Bandit";
    input.setAttribute("accept", ".py,.zip,.tar,.gz,.tar.gz");
  }
  if (tool === "trivy") {
    document.getElementById("trivyBtn").classList.add("active");
    label.innerText = "Upload project/archive for Trivy (Dockerfile, package manifests, etc.)";
    input.setAttribute("accept", ".zip,.tar,.gz,.tgz,.tar.gz,.dockerfile,.txt,.lock");
  }
  if (tool === "codeql") {
    document.getElementById("codeqlBtn").classList.add("active");
    label.innerText = "Upload project archive for CodeQL";
    input.setAttribute("accept", ".zip,.tar,.gz,.tgz,.tar.gz");
  }
}

document.getElementById("fileInput").addEventListener("change", function() {
  document.getElementById("analyzeBtn").disabled = !this.files.length;
});

async function analyze() {
  const fileEl = document.getElementById('fileInput');
  if (!fileEl.files.length) return;
  const fd = new FormData();
  fd.append('tool', currentTool);
  fd.append('file', fileEl.files[0]);
  const btn = document.getElementById('analyzeBtn');
  btn.disabled = true; btn.innerText = 'Running...';
  try {
    const res = await fetch('/api/analyze', { method: 'POST', body: fd });
    const job = await res.json();
    localStorage.setItem('aifx_job', JSON.stringify(job));
    window.location.href = 'results.html';
  } catch (e) {
    alert('Failed to analyze: ' + e);
  } finally {
    btn.disabled = false; btn.innerText = 'Analyze';
  }
}


async function askQwenFixes(){
  const job = JSON.parse(localStorage.getItem('aifx_job')||'{}');
  const panel = document.getElementById('qwenPanel');
  if(!job.job_id){ alert('No job found'); return; }
  panel.style.display = 'block';
  panel.textContent = 'Asking Qwen...';
  try{
    const res = await fetch('/api/qwen_suggest', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({job_id: job.job_id})
    });
    const data = await res.json();
    panel.textContent = data.suggestions || '(no suggestions)';
  }catch(e){
    panel.textContent = 'Failed to contact AI: ' + e;
  }
}

let chatOpen = false;
let chatHistory = [{role:'system', content:'You are Qwen, a helpful DevSecOps assistant for AIFORTRESS. Give concise, code-focused answers.'}];

function toggleChat(){
  chatOpen = !chatOpen;
  const box = document.getElementById('chatBox');
  if(!box) return;
  box.style.display = chatOpen ? 'flex' : 'none';
  if(chatOpen){ renderChat(); }
}

function renderChat(){
  const box = document.getElementById('chatMsgs');
  if(!box) return;
  box.innerHTML = '';
  chatHistory.forEach(m => {
    if(m.role === 'system') return;
    const div = document.createElement('div');
    div.style.margin = '6px 0';
    div.innerHTML = '<b>' + (m.role==='user'?'You':'Qwen') + ':</b> ' + escapeHTML(m.content);
    box.appendChild(div);
  });
  box.scrollTop = box.scrollHeight;
}

async function sendChat(){
  const input = document.getElementById('chatInput');
  if(!input) return;
  const msg = input.value.trim();
  if(!msg) return;
  chatHistory.push({role:'user', content: msg});
  input.value = '';
  renderChat();
  try{
    const res = await fetch('/api/chat', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({messages: chatHistory})
    });
    const data = await res.json();
    const reply = data.reply || '(no reply)';
    chatHistory.push({role:'assistant', content: reply});
    renderChat();
  }catch(e){
    chatHistory.push({role:'assistant', content: 'Failed to reach AI: ' + e});
    renderChat();
  }
}


function logAi(role, text){
  const box = document.getElementById('aiChatLog');
  if(!box) return;
  const div = document.createElement('div');
  div.style.whiteSpace = 'pre-wrap';
  div.textContent = `${role}: ${text}`;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

async function aiDirectChat(message){
  const messages = (window._aiMsgs ||= []);
  messages.push({ role: 'user', content: message });
  logAi('You', message);
  const res = await fetch('/api/ai/chat', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ messages })
  });
  let data; 
  try { data = await res.json(); } 
  catch(e){ data = { error: 'Invalid JSON from server' }; }
  if(data && data.reply){
    messages.push({ role: 'assistant', content: data.reply });
    logAi('AI', data.reply);
  } else {
    logAi('AI-ERROR', JSON.stringify(data));
  }
}

// اربط الأزرار بعد ما الـ DOM يجهز
window.addEventListener('DOMContentLoaded', () => {
  const sendBtn = document.getElementById('aiChatSend');
  const sendFindingsBtn = document.getElementById('aiSendFindings');
  const ta = document.getElementById('aiChatInput');

  sendBtn?.addEventListener('click', () => {
    const msg = (ta?.value || '').trim();
    if(!msg) return;
    ta.value = '';
    aiDirectChat(msg);
  });

  sendFindingsBtn?.addEventListener('click', async () => {
    const job = JSON.parse(localStorage.getItem('aifx_job') || '{}');
    const job_id = job.job_id || job.id;
    if(!job_id){ alert('No job found'); return; }

    const res = await fetch('/api/ai/suggest_from_job', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ job_id })
    });
    let data; 
    try { data = await res.json(); } 
    catch(e){ data = { error: 'Invalid JSON from server' }; }
    if(data && data.suggestions){
      logAi('AI (Fixes)', data.suggestions);
    } else {
      logAi('AI-ERROR', JSON.stringify(data));
    }
  });
});


document.getElementById('aiChatSend')?.addEventListener('click', () => {
  const ta = document.getElementById('aiChatInput');
  const msg = (ta?.value || '').trim();
  if(!msg) return;
  ta.value = '';
  aiDirectChat(msg);
});

document.getElementById('aiSendFindings')?.addEventListener('click', async () => {
  const job = JSON.parse(localStorage.getItem('aifx_job') || '{}');
  const job_id = job.job_id || job.id;
  if(!job_id){ alert('No job found'); return; }
  const res = await fetch('/api/ai/suggest_from_job', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ job_id })
  });
  let data; 
  try { data = await res.json(); } 
  catch(e){ data = { error: 'Invalid JSON from server' }; }
  if(data && data.suggestions){
    logAi('AI (Fixes)', data.suggestions);
  } else {
    logAi('AI-ERROR', JSON.stringify(data));
  }
});
