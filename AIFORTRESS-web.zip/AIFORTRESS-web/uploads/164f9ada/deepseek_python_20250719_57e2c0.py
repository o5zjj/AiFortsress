from fastapi import FastAPI, HTTPException, UploadFile, File, Form
import requests
import json

app = FastAPI()

OLLAMA_API_URL = "http://localhost:11434/api/generate"  # افتراضي port لـ Ollama

@app.post("/diagnose")
async def diagnose_car(
    description: str = Form(...),
    obd_code: str = Form(None),
    audio: UploadFile = File(None),
    image: UploadFile = File(None)
):
    # 1. معالجة المدخلات (الصوت/الصورة إذا وُجدت)
    inputs = {
        "description": description,
        "obd_code": obd_code,
        "audio_transcript": await transcribe_audio(audio) if audio else None,
        "image_analysis": await analyze_image(image) if image else None,
    }

    # 2. إرسال إلى Ollama
    prompt = f"""
    أنا أحتاج تشخيص عطل سيارة بناءً على:
    - الوصف: {inputs['description']}
    - رمز OBD-II: {inputs['obd_code']}
    - نص الصوت: {inputs['audio_transcript']}
    - تحليل الصورة: {inputs['image_analysis']}
    """
    
    response = requests.post(
        OLLAMA_API_URL,
        json={
            "model": "deepseek-chat",
            "prompt": prompt,
            "stream": False  # لاستجابة مباشرة (غير متدفقة)
        }
    )
    
    if response.status_code != 200:
        raise HTTPException(status_code=500, detail="خطأ في الاتصال بـ Ollama")
    
    diagnosis = response.json()["response"]
    return {"diagnosis": diagnosis}

# نفس دوال معالجة الصوت/الصور من المثال السابق
async def transcribe_audio(audio_file: UploadFile):
    # ... (استخدم Whisper أو أي نموذج تحويل صوت إلى نص)
    return "نص الصوت الم transcribed"

async def analyze_image(image_file: UploadFile):
    # ... (استخدم OpenCV/YOLO لتحليل الصور)
    return "نتيجة تحليل الصورة"