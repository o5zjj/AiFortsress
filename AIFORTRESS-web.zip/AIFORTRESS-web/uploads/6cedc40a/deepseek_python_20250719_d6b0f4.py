import streamlit as st
import requests

st.title("🔧 تشخيص أعطال السيارات (متصلة بـ Ollama)")

description = st.text_area("وصف العطل:")
obd_code = st.text_input("رمز OBD-II (اختياري):")
audio = st.file_uploader("رفع تسجيل صوتي (MP3/WAV):", type=["mp3", "wav"])
image = st.file_uploader("رفع صورة العطل:", type=["jpg", "png"])

if st.button("تشخيص"):
    files = {}
    if audio:
        files["audio"] = audio
    if image:
        files["image"] = image
    
    response = requests.post(
        "http://localhost:8000/diagnose",
        data={"description": description, "obd_code": obd_code},
        files=files
    )
    
    if response.status_code == 200:
        st.success("✅ التشخيص:")
        st.markdown(response.json()["diagnosis"])
    else:
        st.error("❌ فشل في التشخيص. حاول مرة أخرى.")